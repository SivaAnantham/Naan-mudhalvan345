# Damaged Car Image Preprocessing Pipeline

This project preprocesses images of damaged cars for computer vision applications using OpenCV and Streamlit.