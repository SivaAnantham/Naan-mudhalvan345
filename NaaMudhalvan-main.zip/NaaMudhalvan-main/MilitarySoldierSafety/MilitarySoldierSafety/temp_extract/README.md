# Military Soldier Safety and Weapon Detection using YOLO

This project uses YOLO and Computer Vision to detect weapons, soldiers, and vehicles for enhancing military safety.